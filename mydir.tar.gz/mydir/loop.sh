for (( ; ;))
do 
continue
done
